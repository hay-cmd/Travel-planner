import { useEffect, useMemo, useState } from "react";
import { create } from "zustand";
import {
  Plane,
  Home,
  CalendarClock,
  Wallet,
  Wrench,
  Plus,
  MapPin,
  Sun,
  CloudSun,
  Cloud,
  CloudRain,
  CloudSnow,
  Trash2,
  Edit3,
  GripVertical,
  Menu,
  X,
  CheckCircle2,
  ChevronRight,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import * as Dialog from "@radix-ui/react-dialog";
import {
  DragDropContext,
  Droppable,
  Draggable,
  type DropResult,
} from "@hello-pangea/dnd";
import {
  PieChart as RePieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
} from "recharts";

// --- Data Types ---

type ActivityType = "Food" | "Sightseeing" | "Transport" | "Hotel" | "Shopping";

type WeatherCondition = "sunny" | "cloudy" | "overcast" | "rain" | "snow";

interface Activity {
  id: string;
  time: string;
  type: ActivityType;
  location: string;
  note?: string;
  cost: number;
}

interface DayWeather {
  condition: WeatherCondition;
  min: number;
  max: number;
  summary: string;
}

interface DayPlan {
  day: number;
  date: string; // YYYY-MM-DD
  activities: Activity[];
  weather: DayWeather;
}

interface TripBudget {
  total: number;
  spent: number;
}

interface ChecklistItem {
  id: string;
  item: string;
  completed: boolean;
}

interface Trip {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  status: "planning" | "ongoing" | "completed";
  coverImage: string;
  destination?: string;
  dailyItinerary: DayPlan[];
  budget: TripBudget;
  checklist: ChecklistItem[];
}

type Page = "dashboard" | "trip" | "budget" | "toolbox";

interface TripsState {
  trips: Trip[];
  selectedTripId: string | null;
  currentPage: Page;
  setPage: (page: Page) => void;
  setSelectedTrip: (id: string | null) => void;
  addTrip: (trip: Omit<Trip, "id" | "status" | "dailyItinerary" | "budget" | "checklist"> & {
    days: number;
  }) => void;
  updateTrip: (id: string, updater: (trip: Trip) => Trip) => void;
  deleteTrip: (id: string) => void;
  addActivity: (tripId: string, day: number, activity: Omit<Activity, "id">) => void;
  updateActivity: (
    tripId: string,
    day: number,
    activityId: string,
    updater: (activity: Activity) => Activity
  ) => void;
  deleteActivity: (tripId: string, day: number, activityId: string) => void;
  reorderActivities: (
    tripId: string,
    day: number,
    sourceIndex: number,
    destinationIndex: number
  ) => void;
  addChecklistItem: (tripId: string, item: string) => void;
  toggleChecklistItem: (tripId: string, itemId: string) => void;
}

const STORAGE_KEY = "jp_travel_trips_v1";

// --- Helpers ---

const uuid = () => crypto.randomUUID();

function getWeatherForIndex(index: number): DayWeather {
  const conditions: WeatherCondition[] = [
    "sunny",
    "cloudy",
    "overcast",
    "rain",
    "sunny",
    "snow",
  ];
  const condition = conditions[index % conditions.length];
  const ranges: Record<WeatherCondition, { min: number; max: number; summary: string }> = {
    sunny: { min: 10, max: 20, summary: "晴朗溫和" },
    cloudy: { min: 8, max: 18, summary: "多雲時晴" },
    overcast: { min: 6, max: 15, summary: "陰天" },
    rain: { min: 5, max: 14, summary: "有雨，建議攜帶雨具" },
    snow: { min: -1, max: 5, summary: "可能降雪，請注意保暖" },
  };
  return {
    condition,
    ...ranges[condition],
  };
}

function formatDate(dateStr: string) {
  const d = new Date(dateStr + "T00:00:00");
  if (Number.isNaN(d.getTime())) return dateStr;
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()}`;
}

function daysBetween(start: string, end: string) {
  const s = new Date(start + "T00:00:00");
  const e = new Date(end + "T00:00:00");
  const diff = e.getTime() - s.getTime();
  return Math.max(1, Math.round(diff / (1000 * 60 * 60 * 24)) + 1);
}

function daysUntil(start: string) {
  const today = new Date();
  const s = new Date(start + "T00:00:00");
  const diff = s.getTime() - today.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function calculateTripProgress(trip: Trip): number {
  const totalDays = trip.dailyItinerary.length || 1;
  const withActivities = trip.dailyItinerary.filter((d) => d.activities.length > 0).length;
  return Math.round((withActivities / totalDays) * 100);
}

function calculateBudgetFromActivities(trip: Trip) {
  const spent = trip.dailyItinerary.reduce((sum, day) => {
    return (
      sum +
      day.activities.reduce((s, a) => {
        return s + (a.cost || 0);
      }, 0)
    );
  }, 0);
  return { ...trip.budget, spent };
}

function loadInitialTrips(): Trip[] {
  if (typeof window === "undefined") return getSeedTrips();
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return getSeedTrips();
    const parsed = JSON.parse(raw) as Trip[];
    return parsed;
  } catch {
    return getSeedTrips();
  }
}

function saveTrips(trips: Trip[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(trips));
  } catch {
    // ignore
  }
}

function getSeedTrips(): Trip[] {
  const seedId = uuid();
  const days = daysBetween("2026-03-13", "2026-03-15");
  const daily: DayPlan[] = Array.from({ length: days }).map((_, idx) => {
    const baseDate = new Date("2026-03-13T00:00:00");
    baseDate.setDate(baseDate.getDate() + idx);
    const dateStr = baseDate.toISOString().slice(0, 10);
    const weather = getWeatherForIndex(idx);
    let activities: Activity[] = [];
    if (idx === 0) {
      activities = [
        {
          id: uuid(),
          time: "10:00",
          type: "Sightseeing",
          location: "淺草寺",
          note: "初次到訪，感受下町風情",
          cost: 0,
        },
        {
          id: uuid(),
          time: "12:30",
          type: "Food",
          location: "一蘭拉麵",
          note: "午餐",
          cost: 1500,
        },
      ];
    }
    return {
      day: idx + 1,
      date: dateStr,
      activities,
      weather,
    };
  });

  const checklist: ChecklistItem[] = [
    "護照、簽證",
    "信用卡、現金",
    "手機、充電器",
    "行李打包",
    "飯店預訂確認",
    "機票確認",
    "常用藥品",
    "相機、記憶卡",
    "雨具",
    "轉接頭",
  ].map((item) => ({ id: uuid(), item, completed: false }));

  const trip: Trip = {
    id: seedId,
    title: "2026 京都春季之行",
    startDate: "2026-03-13",
    endDate: "2026-03-15",
    status: "planning",
    coverImage:
      "https://images.pexels.com/photos/208773/pexels-photo-208773.jpeg?auto=compress&cs=tinysrgb&w=1200",
    destination: "京都",
    dailyItinerary: daily,
    budget: { total: 200000, spent: 15000 },
    checklist,
  };
  trip.budget = calculateBudgetFromActivities(trip);
  return [trip];
}

// --- Zustand Store ---

const useTripsStore = create<TripsState>((set, get) => ({
  trips: [],
  selectedTripId: null,
  currentPage: "dashboard",
  setPage: (page) => set({ currentPage: page }),
  setSelectedTrip: (id) => set({ selectedTripId: id }),
  addTrip: (payload) => {
    const { trips } = get();
    const { title, startDate, endDate, coverImage, destination, days } = payload;
    const dayCount = days || daysBetween(startDate, endDate);
    const daily: DayPlan[] = Array.from({ length: dayCount }).map((_, idx) => {
      const baseDate = new Date(startDate + "T00:00:00");
      baseDate.setDate(baseDate.getDate() + idx);
      const dateStr = baseDate.toISOString().slice(0, 10);
      return {
        day: idx + 1,
        date: dateStr,
        activities: [],
        weather: getWeatherForIndex(idx),
      };
    });
    const checklist: ChecklistItem[] = [
      "護照、簽證",
      "信用卡、現金",
      "手機、充電器",
      "行李打包",
    ].map((item) => ({ id: uuid(), item, completed: false }));

    const newTrip: Trip = {
      id: uuid(),
      title,
      startDate,
      endDate,
      status: "planning",
      coverImage,
      destination,
      dailyItinerary: daily,
      budget: { total: 0, spent: 0 },
      checklist,
    };
    const updated = [...trips, newTrip];
    saveTrips(updated);
    set({ trips: updated, selectedTripId: newTrip.id });
  },
  updateTrip: (id, updater) => {
    const { trips } = get();
    const updated = trips.map((t) => {
      if (t.id !== id) return t;
      const next = updater(t);
      next.budget = calculateBudgetFromActivities(next);
      return next;
    });
    saveTrips(updated);
    set({ trips: updated });
  },
  deleteTrip: (id) => {
    const { trips, selectedTripId } = get();
    const updated = trips.filter((t) => t.id !== id);
    saveTrips(updated);
    set({ trips: updated, selectedTripId: selectedTripId === id ? null : selectedTripId });
  },
  addActivity: (tripId, day, activity) => {
    get().updateTrip(tripId, (trip) => {
      const daily = trip.dailyItinerary.map((d) => {
        if (d.day !== day) return d;
        return {
          ...d,
          activities: [...d.activities, { ...activity, id: uuid() }],
        };
      });
      return { ...trip, dailyItinerary: daily };
    });
  },
  updateActivity: (tripId, day, activityId, updater) => {
    get().updateTrip(tripId, (trip) => {
      const daily = trip.dailyItinerary.map((d) => {
        if (d.day !== day) return d;
        return {
          ...d,
          activities: d.activities.map((a) => (a.id === activityId ? updater(a) : a)),
        };
      });
      return { ...trip, dailyItinerary: daily };
    });
  },
  deleteActivity: (tripId, day, activityId) => {
    get().updateTrip(tripId, (trip) => {
      const daily = trip.dailyItinerary.map((d) => {
        if (d.day !== day) return d;
        return {
          ...d,
          activities: d.activities.filter((a) => a.id !== activityId),
        };
      });
      return { ...trip, dailyItinerary: daily };
    });
  },
  reorderActivities: (tripId, day, sourceIndex, destinationIndex) => {
    if (sourceIndex === destinationIndex) return;
    get().updateTrip(tripId, (trip) => {
      const daily = trip.dailyItinerary.map((d) => {
        if (d.day !== day) return d;
        const items = [...d.activities];
        const [removed] = items.splice(sourceIndex, 1);
        items.splice(destinationIndex, 0, removed);
        return { ...d, activities: items };
      });
      return { ...trip, dailyItinerary: daily };
    });
  },
  addChecklistItem: (tripId, item) => {
    get().updateTrip(tripId, (trip) => ({
      ...trip,
      checklist: [
        ...trip.checklist,
        { id: uuid(), item, completed: false },
      ],
    }));
  },
  toggleChecklistItem: (tripId, itemId) => {
    get().updateTrip(tripId, (trip) => ({
      ...trip,
      checklist: trip.checklist.map((c) =>
        c.id === itemId ? { ...c, completed: !c.completed } : c
      ),
    }));
  },
}));

// Load initial trips once on first mount
function useInitTrips() {
  const [initialized, setInitialized] = useState(false);
  const trips = useTripsStore((s) => s.trips);
  useEffect(() => {
    if (initialized || trips.length > 0) return;
    const seed = loadInitialTrips();
    useTripsStore.setState({ trips: seed, selectedTripId: seed[0]?.id ?? null });
    setInitialized(true);
  }, [initialized, trips.length]);
}

// --- Icon helpers ---

function WeatherIcon({ condition }: { condition: WeatherCondition }) {
  const cls = "h-4 w-4 text-amber-700";
  switch (condition) {
    case "sunny":
      return <Sun className={cls} />;
    case "cloudy":
      return <CloudSun className={cls} />;
    case "overcast":
      return <Cloud className={cls} />;
    case "rain":
      return <CloudRain className={cls} />;
    case "snow":
      return <CloudSnow className={cls} />;
    default:
      return <Sun className={cls} />;
  }
}

function ActivityTypeBadge({ type }: { type: ActivityType }) {
  const config: Record<ActivityType, { label: string; color: string }> = {
    Food: { label: "餐廳", color: "bg-orange-100 text-orange-700" },
    Sightseeing: { label: "景點", color: "bg-sky-100 text-sky-700" },
    Transport: { label: "交通", color: "bg-emerald-100 text-emerald-700" },
    Hotel: { label: "住宿", color: "bg-violet-100 text-violet-700" },
    Shopping: { label: "購物", color: "bg-pink-100 text-pink-700" },
  };
  const { label, color } = config[type];
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${color}`}
    >
      {label}
    </span>
  );
}

// --- Layout ---

function AppLayout() {
  const page = useTripsStore((s) => s.currentPage);
  const setPage = useTripsStore((s) => s.setPage);
  const trips = useTripsStore((s) => s.trips);
  const selectedTripId = useTripsStore((s) => s.selectedTripId);
  const setSelectedTrip = useTripsStore((s) => s.setSelectedTrip);

  const [mobileOpen, setMobileOpen] = useState(false);

  const currentTrip = useMemo(
    () => trips.find((t) => t.id === selectedTripId) ?? trips[0],
    [trips, selectedTripId]
  );

  const navItems: { key: Page; label: string; icon: React.ReactNode }[] = [
    { key: "dashboard", label: "首頁", icon: <Home className="h-4 w-4" /> },
    {
      key: "trip",
      label: "行程規劃",
      icon: <CalendarClock className="h-4 w-4" />,
    },
    { key: "budget", label: "預算追蹤", icon: <Wallet className="h-4 w-4" /> },
    { key: "toolbox", label: "旅行工具", icon: <Wrench className="h-4 w-4" /> },
  ];

  const handleNavClick = (key: Page) => {
    setPage(key);
    setMobileOpen(false);
  };

  useEffect(() => {
    if (!selectedTripId && trips[0]) {
      setSelectedTrip(trips[0].id);
    }
  }, [selectedTripId, setSelectedTrip, trips]);

  return (
    <div className="min-h-screen bg-[#FAF9F6] text-neutral-800">
      <div className="mx-auto flex max-w-6xl gap-6 px-4 py-6 lg:px-8">
        {/* Sidebar (desktop) */}
        <aside className="hidden w-64 flex-shrink-0 flex-col justify-between rounded-3xl border border-neutral-200/80 bg-white/70 p-4 shadow-sm backdrop-blur-md lg:flex">
          <div className="space-y-6">
            <div className="flex items-center gap-3 px-1">
              <div className="flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-200 to-rose-100 text-amber-800 shadow-sm">
                <Plane className="h-4 w-4" />
              </div>
              <div className="leading-tight">
                <p className="text-sm font-medium tracking-tight">日本旅遊</p>
                <p className="text-xs text-neutral-500">Muji Minimal Planner</p>
              </div>
            </div>

            <nav className="space-y-1">
              {navItems.map((item) => {
                const active = page === item.key;
                return (
                  <button
                    key={item.key}
                    onClick={() => handleNavClick(item.key)}
                    className={`flex w-full items-center gap-2 rounded-2xl px-3 py-2 text-sm transition-colors ${
                      active
                        ? "bg-[#E8E4C6] text-neutral-900"
                        : "text-neutral-600 hover:bg-neutral-100/80"
                    }`}
                  >
                    {item.icon}
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>

            {currentTrip && (
              <div className="mt-4 rounded-2xl bg-neutral-50/80 p-3 text-xs text-neutral-600">
                <p className="mb-1 text-[11px] uppercase tracking-[0.16em] text-neutral-400">
                  當前旅程
                </p>
                <p className="truncate text-sm font-medium text-neutral-900">
                  {currentTrip.title}
                </p>
                <p className="mt-1 flex items-center gap-1 text-[11px] text-neutral-500">
                  <MapPin className="h-3 w-3" />
                  {currentTrip.destination ?? "日本"}
                </p>
                <p className="mt-1 text-[11px] text-neutral-500">
                  {formatDate(currentTrip.startDate)} – {formatDate(currentTrip.endDate)}
                </p>
              </div>
            )}
          </div>

          <div className="rounded-2xl bg-rose-50/80 p-3 text-xs text-rose-700">
            <p className="font-medium">小提示</p>
            <p className="mt-1 leading-relaxed">
              保留一點空白，讓旅程有機會發生驚喜。
            </p>
          </div>
        </aside>

        {/* Main area */}
        <div className="flex-1 space-y-4">
          {/* Mobile header */}
          <header className="flex items-center justify-between rounded-3xl border border-neutral-200/80 bg-white/80 px-4 py-3 shadow-sm backdrop-blur-md lg:hidden">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-200 to-rose-100 text-amber-800 shadow-sm">
                <Plane className="h-4 w-4" />
              </div>
              <div className="leading-tight">
                <p className="text-sm font-medium tracking-tight">日本旅遊</p>
                <p className="text-[11px] text-neutral-500">Minimal Planner</p>
              </div>
            </div>
            <button
              className="rounded-full border border-neutral-200 bg-white/70 p-1.5 text-neutral-700 shadow-sm"
              onClick={() => setMobileOpen((v) => !v)}
            >
              {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </header>

          {/* Mobile nav */}
          <AnimatePresence>
            {mobileOpen && (
              <motion.nav
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="space-y-2 rounded-3xl border border-neutral-200/80 bg-white/90 p-3 shadow-sm backdrop-blur-md lg:hidden"
              >
                {navItems.map((item) => {
                  const active = page === item.key;
                  return (
                    <button
                      key={item.key}
                      onClick={() => handleNavClick(item.key)}
                      className={`flex w-full items-center gap-2 rounded-2xl px-3 py-2 text-sm transition-colors ${
                        active
                          ? "bg-[#E8E4C6] text-neutral-900"
                          : "text-neutral-600 hover:bg-neutral-100/80"
                      }`}
                    >
                      {item.icon}
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </motion.nav>
            )}
          </AnimatePresence>

          <main className="min-h-[70vh] rounded-3xl border border-neutral-200/80 bg-white/80 p-4 shadow-sm backdrop-blur-md sm:p-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={page}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.18, ease: "easeOut" }}
                className="space-y-4"
              >
                {page === "dashboard" && <Dashboard />}
                {page === "trip" && <TripDetail />}
                {page === "budget" && <BudgetPage />}
                {page === "toolbox" && <ToolboxPage />}
              </motion.div>
            </AnimatePresence>
          </main>
        </div>
      </div>
    </div>
  );
}

// --- Dashboard ---

function Dashboard() {
  const trips = useTripsStore((s) => s.trips);
  const setPage = useTripsStore((s) => s.setPage);
  const setSelectedTrip = useTripsStore((s) => s.setSelectedTrip);

  const [open, setOpen] = useState(false);

  const handleOpenTrip = (id: string) => {
    setSelectedTrip(id);
    setPage("trip");
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-neutral-900 sm:text-2xl">
            我的旅程
          </h1>
          <p className="mt-1 text-sm text-neutral-500">開始規劃你的下一趟旅行。</p>
        </div>
        <Dialog.Root open={open} onOpenChange={setOpen}>
          <Dialog.Trigger asChild>
            <button className="inline-flex items-center gap-2 rounded-2xl border border-dashed border-amber-300 bg-amber-50/60 px-4 py-2 text-sm font-medium text-amber-800 shadow-sm transition hover:border-amber-400 hover:bg-amber-100/80">
              <Plus className="h-4 w-4" />
              新增旅程
            </button>
          </Dialog.Trigger>
          <CreateTripModal onClose={() => setOpen(false)} />
        </Dialog.Root>
      </div>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {trips.map((trip) => (
          <TripCard key={trip.id} trip={trip} onOpen={() => handleOpenTrip(trip.id)} />
        ))}
      </div>

      {trips.length === 0 && (
        <p className="text-sm text-neutral-400">目前尚未建立任何旅程。</p>
      )}
    </div>
  );
}

function TripCard({ trip, onOpen }: { trip: Trip; onOpen: () => void }) {
  const deleteTrip = useTripsStore((s) => s.deleteTrip);
  const progress = calculateTripProgress(trip);
  const dUntil = daysUntil(trip.startDate);
  const isFuture = dUntil > 0;

  return (
    <motion.div
      whileHover={{ y: -4, boxShadow: "0 20px 40px rgba(15,23,42,0.06)" }}
      className="group flex cursor-pointer flex-col overflow-hidden rounded-3xl border border-neutral-200/80 bg-neutral-50/80 shadow-sm transition"
      onClick={onOpen}
    >
      <div className="relative h-32 overflow-hidden bg-neutral-200">
        {trip.coverImage && (
          <img
            src={trip.coverImage}
            alt={trip.title}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-black/10 to-transparent" />
        <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-xs text-white">
          <div className="flex flex-col gap-0.5">
            <span className="text-[11px] uppercase tracking-[0.15em] text-neutral-200">
              {trip.destination ?? "Japan"}
            </span>
            <span className="text-sm font-medium">{trip.title}</span>
          </div>
          <div className="rounded-full bg-black/30 px-2 py-1 text-[11px] backdrop-blur">
            {formatDate(trip.startDate)} – {formatDate(trip.endDate)}
          </div>
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-3 p-3.5">
        <div className="flex items-center justify-between gap-2 text-xs text-neutral-500">
          <span>
            {daysBetween(trip.startDate, trip.endDate)} 天行程
          </span>
          <span>
            {isFuture
              ? `距離出發還有 ${dUntil} 天`
              : dUntil === 0
              ? "今天出發"
              : "已出發"}
          </span>
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs text-neutral-500">
            <span>行程規劃進度</span>
            <span className="font-medium text-neutral-700">{progress}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-neutral-200">
            <div
              className="h-full rounded-full bg-gradient-to-r from-amber-400 to-amber-600"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
        <div className="mt-auto flex items-center justify-between text-xs text-neutral-500">
          <div className="inline-flex items-center gap-1 rounded-full bg-neutral-100 px-2 py-1">
            <MapPin className="h-3 w-3" />
            <span>{trip.destination ?? "日本"}</span>
          </div>
          <button
            className="flex items-center gap-1 rounded-full px-2 py-1 text-[11px] text-neutral-500 hover:bg-neutral-100"
            onClick={(e) => {
              e.stopPropagation();
              deleteTrip(trip.id);
            }}
          >
            <Trash2 className="h-3 w-3" /> 刪除
          </button>
        </div>
      </div>
    </motion.div>
  );
}

// --- Create Trip Modal ---

interface CreateTripModalProps {
  onClose: () => void;
}

function CreateTripModal({ onClose }: CreateTripModalProps) {
  const addTrip = useTripsStore((s) => s.addTrip);
  const [title, setTitle] = useState("");
  const [destination, setDestination] = useState("日本");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [coverImage, setCoverImage] = useState("");
  const [days, setDays] = useState<number | null>(null);

  useEffect(() => {
    if (startDate && endDate) {
      setDays(daysBetween(startDate, endDate));
    }
  }, [startDate, endDate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !startDate || !endDate) return;
    addTrip({ title, startDate, endDate, coverImage, destination, days: days ?? 1 });
    onClose();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        setCoverImage(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-40 bg-black/10 backdrop-blur-md" />
      <Dialog.Content className="fixed inset-x-4 top-[15%] z-50 mx-auto max-w-lg rounded-3xl border border-neutral-200/80 bg-white/90 p-5 shadow-xl backdrop-blur-md">
        <Dialog.Title className="text-base font-medium text-neutral-900">
          新增旅程
        </Dialog.Title>
        <Dialog.Description className="mt-1 text-xs text-neutral-500">
          填寫旅程資訊，開始你的下一趟旅程規劃。
        </Dialog.Description>
        <form className="mt-4 space-y-3" onSubmit={handleSubmit}>
          <div className="space-y-1">
            <label className="text-xs text-neutral-600">旅程標題</label>
            <input
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-sm outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="例如：2026 京都春季之行"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-neutral-600">目的地</label>
            <input
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-sm outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="東京 / 京都 / 大阪..."
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <label className="text-xs text-neutral-600">開始日期</label>
              <input
                type="date"
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-sm outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-neutral-600">結束日期</label>
              <input
                type="date"
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-sm outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </div>
          {days && (
            <p className="text-xs text-neutral-500">
              共 {days} 天行程。
            </p>
          )}
          <div className="space-y-1">
            <label className="text-xs text-neutral-600">封面圖片</label>
            <div className="flex items-center gap-3">
              <input
                type="url"
                className="flex-1 rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-xs outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
                value={coverImage}
                onChange={(e) => setCoverImage(e.target.value)}
                placeholder="或貼上圖片 URL"
              />
              <label className="inline-flex cursor-pointer items-center rounded-2xl border border-neutral-200 bg-neutral-50/80 px-3 py-2 text-xs text-neutral-700 hover:bg-neutral-100">
                上傳
                <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
              </label>
            </div>
            <p className="text-[11px] text-neutral-400">
              支援本地檔案上傳（以 base64 形式保存）。
            </p>
          </div>
          <div className="mt-4 flex justify-end gap-2 text-sm">
            <Dialog.Close asChild>
              <button
                type="button"
                className="rounded-2xl px-3 py-1.5 text-xs text-neutral-500 hover:bg-neutral-100"
                onClick={onClose}
              >
                取消
              </button>
            </Dialog.Close>
            <button
              type="submit"
              className="rounded-2xl bg-neutral-900 px-4 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-neutral-800"
            >
              建立旅程
            </button>
          </div>
        </form>
      </Dialog.Content>
    </Dialog.Portal>
  );
}

// --- Trip Detail ---

function TripDetail() {
  const trips = useTripsStore((s) => s.trips);
  const selectedTripId = useTripsStore((s) => s.selectedTripId);
  const setSelectedTrip = useTripsStore((s) => s.setSelectedTrip);

  const [selectedDay, setSelectedDay] = useState(1);

  const trip = useMemo(
    () => trips.find((t) => t.id === selectedTripId) ?? trips[0],
    [trips, selectedTripId]
  );

  useEffect(() => {
    if (!trip) return;
    setSelectedDay(1);
    if (!selectedTripId) setSelectedTrip(trip.id);
  }, [trip?.id]);

  const [activityModalOpen, setActivityModalOpen] = useState(false);
  const [editingActivity, setEditingActivity] = useState<{
    day: number;
    activity: Activity | null;
  }>({ day: 1, activity: null });

  const onAddActivity = (day: number) => {
    setEditingActivity({ day, activity: null });
    setActivityModalOpen(true);
  };

  const onEditActivity = (day: number, activity: Activity) => {
    setEditingActivity({ day, activity });
    setActivityModalOpen(true);
  };

  const onDragEnd = (result: DropResult) => {
    if (!result.destination || !trip) return;
    const sourceIndex = result.source.index;
    const destinationIndex = result.destination.index;
    const dayNumber = Number(result.source.droppableId.replace("day-", ""));
    if (!Number.isFinite(dayNumber)) return;
    useTripsStore
      .getState()
      .reorderActivities(trip.id, dayNumber, sourceIndex, destinationIndex);
  };

  if (!trip) {
    return <p className="text-sm text-neutral-500">請先在首頁建立一個旅程。</p>;
  }

  const dayPlan = trip.dailyItinerary.find((d) => d.day === selectedDay) ??
    trip.dailyItinerary[0];

  return (
    <div className="flex flex-col gap-4 lg:flex-row">
      <div className="w-full space-y-3 lg:w-60">
        <div>
          <h2 className="text-base font-medium text-neutral-900">行程規劃</h2>
          <p className="mt-1 text-xs text-neutral-500">
            選擇天數，拖曳調整每日活動順序。
          </p>
        </div>
        <div className="space-y-2">
          {trip.dailyItinerary.map((d) => (
            <button
              key={d.day}
              onClick={() => setSelectedDay(d.day)}
              className={`flex w-full items-center justify-between rounded-2xl border px-3 py-2 text-left text-xs transition ${
                selectedDay === d.day
                  ? "border-transparent bg-gradient-to-r from-[#E8E4C6] to-amber-50 text-neutral-900 shadow-sm"
                  : "border-neutral-200/80 bg-white/70 text-neutral-600 hover:bg-neutral-50"
              }`}
            >
              <div className="flex flex-col">
                <span className="text-[11px] uppercase tracking-[0.16em] text-neutral-400">
                  Day {d.day}
                </span>
                <span className="text-xs font-medium text-neutral-800">
                  {formatDate(d.date)}
                </span>
                <span className="mt-0.5 text-[11px] text-neutral-500">
                  {d.activities.length} 個活動
                </span>
              </div>
              <div className="flex flex-col items-end gap-1 text-[11px] text-neutral-500">
                <div className="inline-flex items-center gap-1 rounded-full bg-white/70 px-2 py-0.5">
                  <WeatherIcon condition={d.weather.condition} />
                  <span>
                    {d.weather.min}° / {d.weather.max}°C
                  </span>
                </div>
                <span>{d.weather.summary}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-neutral-400">
              Day {dayPlan.day}
            </p>
            <h3 className="text-base font-medium text-neutral-900">
              {formatDate(dayPlan.date)} 的行程
            </h3>
            <p className="mt-1 text-xs text-neutral-500">
              今日天氣：{dayPlan.weather.summary}（{dayPlan.weather.min}° – {dayPlan.weather.max}°C）
            </p>
          </div>
          <Dialog.Root open={activityModalOpen} onOpenChange={setActivityModalOpen}>
            <Dialog.Trigger asChild>
              <button
                onClick={() => onAddActivity(dayPlan.day)}
                className="inline-flex items-center gap-1 rounded-2xl border border-neutral-200 bg-neutral-50 px-3 py-1.5 text-xs text-neutral-700 shadow-sm hover:bg-neutral-100"
              >
                <Plus className="h-3.5 w-3.5" />
                新增活動
              </button>
            </Dialog.Trigger>
            <AddActivityModal
              tripId={trip.id}
              day={editingActivity.day}
              defaultActivity={editingActivity.activity ?? undefined}
              onClose={() => setActivityModalOpen(false)}
            />
          </Dialog.Root>
        </div>

        <DragDropContext onDragEnd={onDragEnd}>
          <Droppable droppableId={`day-${dayPlan.day}`}>
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className="relative border-l border-dashed border-neutral-200 pl-4"
              >
                {dayPlan.activities.length === 0 && (
                  <p className="ml-2 text-xs text-neutral-400">
                    目前尚未安排活動。點擊「新增活動」開始規劃。
                  </p>
                )}
                {dayPlan.activities.map((activity, index) => (
                  <Draggable key={activity.id} draggableId={activity.id} index={index}>
                    {(dragProvided, snapshot) => (
                      <div
                        ref={dragProvided.innerRef}
                        {...dragProvided.draggableProps}
                        className="relative mb-4 flex"
                      >
                        <div className="absolute -left-4 top-3 flex items-center justify-center">
                          <div className="h-2 w-2 rounded-full bg-neutral-400" />
                        </div>
                        <ActivityCard
                          activity={activity}
                          onEdit={() => onEditActivity(dayPlan.day, activity)}
                          onDelete={() =>
                            useTripsStore
                              .getState()
                              .deleteActivity(trip.id, dayPlan.day, activity.id)
                          }
                          dragHandleProps={dragProvided.dragHandleProps}
                          isDragging={snapshot.isDragging}
                        />
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      </div>
    </div>
  );
}

interface ActivityCardProps {
  activity: Activity;
  onEdit: () => void;
  onDelete: () => void;
  dragHandleProps: any;
  isDragging: boolean;
}

function ActivityCard({ activity, onEdit, onDelete, dragHandleProps, isDragging }: ActivityCardProps) {
  return (
    <motion.div
      animate={{ scale: isDragging ? 1.02 : 1 }}
      className="flex-1 rounded-2xl border border-neutral-200/80 bg-white/80 p-3 shadow-sm backdrop-blur-sm"
    >
      <div className="flex items-start gap-3">
        <button
          {...dragHandleProps}
          className="mt-0.5 rounded-full border border-neutral-200 bg-neutral-50 p-1 text-neutral-400 hover:text-neutral-700"
        >
          <GripVertical className="h-3.5 w-3.5" />
        </button>
        <div className="flex-1 space-y-1.5 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-neutral-100 px-2 py-0.5 text-[11px] text-neutral-700">
                {activity.time}
              </span>
              <ActivityTypeBadge type={activity.type} />
            </div>
            <div className="flex items-center gap-1 text-[11px] text-neutral-500">
              <span>預計花費</span>
              <span className="font-medium text-neutral-800">¥{activity.cost.toLocaleString()}</span>
            </div>
          </div>
          <p className="text-sm font-medium text-neutral-900">{activity.location}</p>
          {activity.note && (
            <p className="text-xs text-neutral-500">{activity.note}</p>
          )}
          <div className="flex items-center justify-end gap-2 pt-1 text-[11px]">
            <button
              className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-neutral-500 hover:bg-neutral-100"
              onClick={onEdit}
            >
              <Edit3 className="h-3 w-3" /> 編輯
            </button>
            <button
              className="inline-flex items-center gap-1 rounded-full px-2 py-1 text-neutral-500 hover:bg-neutral-100"
              onClick={onDelete}
            >
              <Trash2 className="h-3 w-3" /> 刪除
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// --- Add Activity Modal ---

interface AddActivityModalProps {
  tripId: string;
  day: number;
  defaultActivity?: Activity;
  onClose: () => void;
}

const ACTIVITY_TYPES: ActivityType[] = [
  "Food",
  "Sightseeing",
  "Transport",
  "Hotel",
  "Shopping",
];

function AddActivityModal({ tripId, day, defaultActivity, onClose }: AddActivityModalProps) {
  const addActivity = useTripsStore((s) => s.addActivity);
  const updateActivity = useTripsStore((s) => s.updateActivity);

  const [type, setType] = useState<ActivityType>(defaultActivity?.type ?? "Sightseeing");
  const [time, setTime] = useState(defaultActivity?.time ?? "10:00");
  const [location, setLocation] = useState(defaultActivity?.location ?? "");
  const [note, setNote] = useState(defaultActivity?.note ?? "");
  const [cost, setCost] = useState(defaultActivity?.cost?.toString() ?? "0");

  const isEdit = !!defaultActivity;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericCost = Number(cost) || 0;
    if (!location) return;
    if (isEdit && defaultActivity) {
      updateActivity(tripId, day, defaultActivity.id, (a) => ({
        ...a,
        type,
        time,
        location,
        note,
        cost: numericCost,
      }));
    } else {
      addActivity(tripId, day, {
        type,
        time,
        location,
        note,
        cost: numericCost,
      });
    }
    onClose();
  };

  return (
    <Dialog.Portal>
      <Dialog.Overlay className="fixed inset-0 z-40 bg-black/10 backdrop-blur-md" />
      <Dialog.Content className="fixed inset-x-4 top-[12%] z-50 mx-auto max-w-md rounded-3xl border border-neutral-200/80 bg-white/90 p-5 shadow-xl backdrop-blur-md">
        <Dialog.Title className="text-sm font-medium text-neutral-900">
          {isEdit ? "編輯活動" : "新增活動"}
        </Dialog.Title>
        <Dialog.Description className="mt-1 text-xs text-neutral-500">
          設定時間、地點與預計花費，拖曳卡片可調整順序。
        </Dialog.Description>
        <form className="mt-4 space-y-3" onSubmit={handleSubmit}>
          <div className="space-y-1">
            <p className="text-xs text-neutral-600">活動類型</p>
            <div className="grid grid-cols-5 gap-1.5">
              {ACTIVITY_TYPES.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`flex flex-col items-center gap-1 rounded-2xl border px-2 py-1.5 text-[11px] transition ${
                    type === t
                      ? "border-amber-400 bg-amber-50 text-amber-800"
                      : "border-neutral-200 bg-neutral-50/60 text-neutral-600 hover:bg-neutral-100"
                  }`}
                >
                  <span>{t === "Food" ? "🍽️" : t === "Sightseeing" ? "📷" : t === "Transport" ? "🚆" : t === "Hotel" ? "🏨" : "🛍️"}</span>
                  <span>
                    {t === "Food"
                      ? "餐廳"
                      : t === "Sightseeing"
                      ? "景點"
                      : t === "Transport"
                      ? "交通"
                      : t === "Hotel"
                      ? "住宿"
                      : "購物"}
                  </span>
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <label className="text-xs text-neutral-600">時間</label>
              <input
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-xs outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs text-neutral-600">預計花費（日圓）</label>
              <input
                type="number"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-xs outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs text-neutral-600">地點名稱</label>
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-xs outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              placeholder="例如：清水寺 / 祇園"
            />
          </div>
          <div className="space-y-1">
            <label className="text-xs text-neutral-600">備註</label>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              rows={3}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/60 px-3 py-2 text-xs outline-none ring-0 transition focus:border-amber-400 focus:bg-white focus:ring-2 focus:ring-amber-100"
              placeholder="簡短說明或注意事項"
            />
          </div>
          <div className="mt-3 flex justify-end gap-2 text-xs">
            <Dialog.Close asChild>
              <button
                type="button"
                className="rounded-2xl px-3 py-1.5 text-neutral-500 hover:bg-neutral-100"
                onClick={onClose}
              >
                取消
              </button>
            </Dialog.Close>
            <button
              type="submit"
              className="rounded-2xl bg-neutral-900 px-4 py-1.5 font-medium text-white shadow-sm hover:bg-neutral-800"
            >
              {isEdit ? "儲存" : "新增"}
            </button>
          </div>
        </form>
      </Dialog.Content>
    </Dialog.Portal>
  );
}

// --- Budget Page ---

const BUDGET_COLORS: Record<string, string> = {
  food: "#fb923c",
  transport: "#34d399",
  accommodation: "#a855f7",
  sightseeing: "#38bdf8",
  shopping: "#f472b6",
  other: "#9ca3af",
};

function BudgetPage() {
  const trips = useTripsStore((s) => s.trips);
  const selectedTripId = useTripsStore((s) => s.selectedTripId);

  const trip = useMemo(
    () => trips.find((t) => t.id === selectedTripId) ?? trips[0],
    [trips, selectedTripId]
  );

  if (!trip) return <p className="text-sm text-neutral-500">請先建立旅程。</p>;

  const budget = calculateBudgetFromActivities(trip);

  const categoryTotals: Record<string, number> = {
    food: 0,
    transport: 0,
    accommodation: 0,
    sightseeing: 0,
    shopping: 0,
    other: 0,
  };

  trip.dailyItinerary.forEach((day) => {
    day.activities.forEach((a) => {
      const value = a.cost || 0;
      switch (a.type) {
        case "Food":
          categoryTotals.food += value;
          break;
        case "Transport":
          categoryTotals.transport += value;
          break;
        case "Hotel":
          categoryTotals.accommodation += value;
          break;
        case "Sightseeing":
          categoryTotals.sightseeing += value;
          break;
        case "Shopping":
          categoryTotals.shopping += value;
          break;
        default:
          categoryTotals.other += value;
      }
    });
  });

  const pieData = Object.entries(categoryTotals)
    .filter(([, v]) => v > 0)
    .map(([key, value]) => ({ name: key, value }));

  const remaining = Math.max(0, budget.total - budget.spent);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-base font-medium text-neutral-900">預算追蹤</h2>
        <p className="mt-1 text-xs text-neutral-500">
          根據每日行程的花費，自動統計各類別支出狀況。
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-neutral-50/70 p-4 shadow-sm md:col-span-2">
          <div className="grid gap-3 sm:grid-cols-3">
            <BudgetSummaryItem label="總預算" value={budget.total} />
            <BudgetSummaryItem label="已花費" value={budget.spent} emphasis />
            <BudgetSummaryItem label="剩餘預算" value={remaining} highlight={remaining <= 0} />
          </div>
          <div className="mt-4 h-44">
            {pieData.length === 0 ? (
              <p className="text-xs text-neutral-400">
                目前尚未有任何花費，新增活動並設定 cost 後會自動統計。
              </p>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <RePieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={45}
                    outerRadius={70}
                    paddingAngle={2}
                  >
                    {pieData.map((entry) => (
                      <Cell
                        key={`cell-${entry.name}`}
                        fill={BUDGET_COLORS[entry.name] ?? "#9ca3af"}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={((value: number | string) => `¥${Number(value).toLocaleString()}`) as any}
                    contentStyle={{
                      borderRadius: 12,
                      border: "1px solid rgba(148,163,184,0.3)",
                      fontSize: 11,
                    }}
                  />
                </RePieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-white/80 p-4 shadow-sm">
          <p className="text-xs text-neutral-500">
            若某一類別支出超過總預算的一半，將以紅色醒目顯示，提醒控制花費。
          </p>
          <div className="space-y-2 text-xs">
            {Object.entries(categoryTotals).map(([key, value]) => {
              const percent = budget.spent ? Math.round((value / budget.spent) * 100) : 0;
              const over = budget.total > 0 && value > budget.total * 0.5;
              const labelMap: Record<string, string> = {
                food: "🍽️ 餐飲",
                transport: "🚆 交通",
                accommodation: "🏨 住宿",
                sightseeing: "📷 觀光",
                shopping: "🛍️ 購物",
                other: "📦 其他",
              };
              return (
                <div
                  key={key}
                  className={`rounded-2xl border px-3 py-2 ${
                    over
                      ? "border-rose-200 bg-rose-50/90"
                      : "border-neutral-200/80 bg-neutral-50/80"
                  }`}
                >
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-neutral-700">{labelMap[key]}</span>
                    <span className="text-neutral-500">
                      ¥{value.toLocaleString()} ({percent}%)
                    </span>
                  </div>
                  <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/70">
                    <div
                      className={`h-full rounded-full ${
                        over
                          ? "bg-rose-400"
                          : "bg-gradient-to-r from-amber-300 to-amber-500"
                      }`}
                      style={{ width: `${Math.min(100, percent)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function BudgetSummaryItem({
  label,
  value,
  emphasis,
  highlight,
}: {
  label: string;
  value: number;
  emphasis?: boolean;
  highlight?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border px-3 py-2 text-xs ${
        highlight
          ? "border-rose-300 bg-rose-50 text-rose-800"
          : "border-neutral-200/80 bg-white/80 text-neutral-700"
      }`}
    >
      <p className="text-[11px] text-neutral-500">{label}</p>
      <p
        className={`mt-1 text-sm font-medium ${
          emphasis ? "text-amber-700" : "text-neutral-900"
        }`}
      >
        ¥{value.toLocaleString()}
      </p>
    </div>
  );
}

// --- Toolbox Page ---

function safeEvalExpression(raw: string): number | null {
  if (!raw.trim()) return null;
  try {
    // Replace percentage expressions like 500*30% -> 500*(30/100)
    const withPercent = raw.replace(/(\d+(?:\.\d+)?)%/g, "($1/100)");
    if (/[^0-9+\-*/().\s]/.test(withPercent)) return null;
    // eslint-disable-next-line no-new-func
    const fn = new Function(`return (${withPercent})`);
    const result = fn();
    if (typeof result !== "number" || Number.isNaN(result)) return null;
    return result;
  } catch {
    return null;
  }
}

function ToolboxPage() {
  const trips = useTripsStore((s) => s.trips);
  const selectedTripId = useTripsStore((s) => s.selectedTripId);
  const addChecklistItem = useTripsStore((s) => s.addChecklistItem);
  const toggleChecklistItem = useTripsStore((s) => s.toggleChecklistItem);

  const trip = useMemo(
    () => trips.find((t) => t.id === selectedTripId) ?? trips[0],
    [trips, selectedTripId]
  );

  const [newItem, setNewItem] = useState("");

  const [jpy, setJpy] = useState(1000);
  const [hkd, setHkd] = useState(0);
  const [rate, setRate] = useState(0.051); // 1 JPY = 0.051 HKD

  const [fxExpr, setFxExpr] = useState("500+200*3");
  const [fxResult, setFxResult] = useState<number | null>(null);

  const [discountExpr, setDiscountExpr] = useState("500*30%");
  const [discountResult, setDiscountResult] = useState<{ jpy: number; hkd: number } | null>(
    null
  );

  const [textInput, setTextInput] = useState("");
  const [translated, setTranslated] = useState("");
  const [uploadedName, setUploadedName] = useState<string | null>(null);

  useEffect(() => {
    setHkd(Number((jpy * rate).toFixed(2)));
  }, [jpy, rate]);

  const handleHkdChange = (value: number) => {
    setHkd(value);
    setJpy(Number((value / rate || 0).toFixed(0)));
  };

  const handleChecklistAdd = () => {
    if (!trip || !newItem.trim()) return;
    addChecklistItem(trip.id, newItem.trim());
    setNewItem("");
  };

  const checklistCompletion = useMemo(() => {
    if (!trip || trip.checklist.length === 0) return 0;
    const done = trip.checklist.filter((c) => c.completed).length;
    return Math.round((done / trip.checklist.length) * 100);
  }, [trip]);

  const handleFxCalculate = () => {
    const result = safeEvalExpression(fxExpr);
    setFxResult(result);
  };

  const handleDiscountCalculate = () => {
    const base = safeEvalExpression(discountExpr);
    if (base == null) {
      setDiscountResult(null);
      return;
    }
    const jpyValue = base;
    const hkdValue = Number((jpyValue * rate).toFixed(2));
    setDiscountResult({ jpy: jpyValue, hkd: hkdValue });
  };

  const handleTranslate = () => {
    // Demo: simply echo back as if translated
    if (!textInput.trim()) {
      setTranslated("");
      return;
    }
    setTranslated(textInput.trim());
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadedName(file.name);
  };

  if (!trip) return <p className="text-sm text-neutral-500">請先建立旅程。</p>;

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="text-base font-medium text-neutral-900">旅行工具箱</h2>
          <p className="mt-1 text-xs text-neutral-500">
            出發前檢查、貨幣換算、折扣計算與簡易文字轉換。
          </p>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {/* Checklist */}
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-neutral-50/80 p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs">
            <div>
              <p className="text-sm font-medium text-neutral-900">出發前檢查清單</p>
              <p className="mt-1 text-[11px] text-neutral-500">此清單與旅程一同儲存。</p>
            </div>
            <div className="flex items-center gap-1 text-[11px] text-neutral-500">
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
              <span>{checklistCompletion}% 完成</span>
            </div>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/80">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-300 to-emerald-500"
              style={{ width: `${checklistCompletion}%` }}
            />
          </div>
          <div className="mt-3 space-y-1.5 text-xs">
            {trip.checklist.map((item) => (
              <label
                key={item.id}
                className="flex cursor-pointer items-center gap-2 rounded-2xl px-2 py-1.5 hover:bg-white/80"
              >
                <input
                  type="checkbox"
                  checked={item.completed}
                  onChange={() => toggleChecklistItem(trip.id, item.id)}
                  className="h-3.5 w-3.5 rounded border-neutral-300 text-emerald-500 focus:ring-emerald-400"
                />
                <span className={item.completed ? "text-neutral-400 line-through" : "text-neutral-700"}>
                  {item.item}
                </span>
              </label>
            ))}
          </div>
          <div className="mt-3 flex gap-2 text-xs">
            <input
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              placeholder="新增自訂項目"
              className="flex-1 rounded-2xl border border-neutral-200 bg-white/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
            />
            <button
              onClick={handleChecklistAdd}
              className="rounded-2xl bg-neutral-900 px-3 py-1.5 font-medium text-white shadow-sm hover:bg-neutral-800"
            >
              新增
            </button>
          </div>
        </div>

        {/* Currency converter */}
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-white/80 p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs">
            <p className="text-sm font-medium text-neutral-900">貨幣轉換器</p>
            <span className="text-[11px] text-neutral-500">1 JPY = {rate.toFixed(3)} HKD</span>
          </div>
          <div className="grid gap-2 text-xs">
            <div className="space-y-1">
              <label className="text-[11px] text-neutral-500">日圓 (JPY)</label>
              <input
                type="number"
                value={jpy}
                onChange={(e) => setJpy(Number(e.target.value) || 0)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
              />
            </div>
            <div className="space-y-1">
              <label className="text-[11px] text-neutral-500">港幣 (HKD)</label>
              <input
                type="number"
                value={hkd}
                onChange={(e) => handleHkdChange(Number(e.target.value) || 0)}
                className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
              />
            </div>
          </div>
          <div className="space-y-1 text-[11px] text-neutral-500">
            <label>自訂匯率</label>
            <input
              type="number"
              step="0.001"
              value={rate}
              onChange={(e) => setRate(Number(e.target.value) || 0.051)}
              className="w-full rounded-2xl border border-neutral-200 bg-neutral-50/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
            />
          </div>
          <div className="space-y-2 rounded-2xl bg-neutral-50/80 p-3 text-[11px] text-neutral-600">
            <p className="font-medium">匯率計算機</p>
            <div className="flex items-center gap-2">
              <input
                value={fxExpr}
                onChange={(e) => setFxExpr(e.target.value)}
                className="flex-1 rounded-2xl border border-neutral-200 bg-white/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
                placeholder="輸入算式，如 500+200*3"
              />
              <button
                onClick={handleFxCalculate}
                className="rounded-2xl bg-neutral-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-neutral-800"
              >
                =
              </button>
            </div>
            {fxResult != null && (
              <p>
                合計約 <span className="font-medium">¥{fxResult.toLocaleString()}</span> ≈
                <span className="font-medium"> HK${(fxResult * rate).toFixed(2)}</span>
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Discount & language */}
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-white/80 p-4 shadow-sm text-xs">
          <p className="text-sm font-medium text-neutral-900">折扣計算機</p>
          <p className="text-[11px] text-neutral-500">
            輸入算式，如 <span className="rounded-full bg-neutral-100 px-1">500*30%</span>。
          </p>
          <div className="flex items-center gap-2">
            <input
              value={discountExpr}
              onChange={(e) => setDiscountExpr(e.target.value)}
              className="flex-1 rounded-2xl border border-neutral-200 bg-neutral-50/80 px-3 py-1.5 outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
            />
            <button
              onClick={handleDiscountCalculate}
              className="rounded-2xl bg-neutral-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-neutral-800"
            >
              =
            </button>
          </div>
          {discountResult && (
            <div className="mt-1 space-y-1 text-[11px] text-neutral-600">
              <p>
                折扣後約 <span className="font-medium">¥{discountResult.jpy.toLocaleString()}</span>
              </p>
              <p>
                以目前匯率換算約{' '}
                <span className="font-medium">HK${discountResult.hkd.toFixed(2)}</span>
              </p>
            </div>
          )}
        </div>
        <div className="space-y-3 rounded-3xl border border-neutral-200/80 bg-neutral-50/80 p-4 shadow-sm text-xs">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-neutral-900">語言轉換器（示意版）</p>
            <span className="rounded-full bg-white/80 px-2 py-0.5 text-[10px] text-neutral-500">
              Demo
            </span>
          </div>
          <p className="text-[11px] text-neutral-500">
            可上傳圖片或貼上文字。此示範版僅顯示原文作為「翻譯」結果，實際專案可串接
            OCR 與翻譯 API（如 Firebase / Supabase Functions）。
          </p>
          <div className="space-y-2">
            <label className="inline-flex cursor-pointer items-center gap-2 rounded-2xl border border-neutral-200 bg-white/90 px-3 py-1.5 text-[11px] text-neutral-600 hover:bg-white">
              上傳相片
              <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
            </label>
            {uploadedName && (
              <p className="text-[11px] text-neutral-500">已選擇檔案：{uploadedName}</p>
            )}
          </div>
          <div className="grid gap-2 md:grid-cols-2">
            <div className="space-y-1">
              <p className="text-[11px] text-neutral-500">原文</p>
              <textarea
                rows={4}
                value={textInput}
                onChange={(e) => setTextInput(e.target.value)}
                placeholder="貼上日文或英文句子..."
                className="w-full rounded-2xl border border-neutral-200 bg-white/90 px-3 py-2 text-xs outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-100"
              />
            </div>
            <div className="space-y-1">
              <p className="text-[11px] text-neutral-500">繁體中文（示意）</p>
              <div className="h-full rounded-2xl border border-dashed border-neutral-200 bg-white/60 px-3 py-2 text-xs text-neutral-700">
                {translated || <span className="text-neutral-400">按下下方按鈕顯示結果</span>}
              </div>
            </div>
          </div>
          <div className="flex justify-end">
            <button
              onClick={handleTranslate}
              className="inline-flex items-center gap-1 rounded-2xl bg-neutral-900 px-3 py-1.5 text-xs font-medium text-white shadow-sm hover:bg-neutral-800"
            >
              <ChevronRight className="h-3 w-3" />
              轉換文字
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Root App ---

export function App() {
  useInitTrips();
  return <AppLayout />;
}
